export function fetchUserData() {
  return {
    name: 'John Doe',
    email: 'john.doe@example.com'
  };
}