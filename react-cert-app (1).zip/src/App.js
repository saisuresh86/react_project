import React from 'react';
import CreateCertificate from './CreateCertificate';

function App() {
  return (
    <div className="App">
      <h1>Certificate Creation</h1>
      <CreateCertificate />
    </div>
  );
}

export default App;