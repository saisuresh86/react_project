import React from 'react';
import CertificateForm from './CertificateForm';

function CreateCertificate() {
  return (
    <div>
      <h2>Create Certificate</h2>
      <CertificateForm />
    </div>
  );
}

export default CreateCertificate;